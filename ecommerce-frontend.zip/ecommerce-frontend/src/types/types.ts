export type ProductType = {
  id: number;
  name: string;
  image: string;
  price: number;
  category: string;
  rating: number;
};
