/**
 * @license MIT
 * @copyright 2025 Bukola David
 */