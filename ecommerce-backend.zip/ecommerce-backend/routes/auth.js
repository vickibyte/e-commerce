const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const protect = require("../middleware/authMiddleware");

const router = express.Router();

// Generate JWT token (include role so middleware can authorize without extra DB hits)
const generateToken = (user) =>
  jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "3d" });

// ===== REGISTER ======
router.post("/register", async (req, res) => {
  const { firstName, lastName, username, email, password, role } = req.body;

  try {
    // Check if email already exists
    if (await User.findOne({ email }))
      return res.status(400).json({ message: "Email already exists!" });

    // Check if username already exists
    if (await User.findOne({ username }))
      return res.status(400).json({ message: "Username already exists!" });

    // Hash password
    const hashed = await bcrypt.hash(password, 10);

    // Create user
    const user = await User.create({
      firstName,
      lastName,
      username,
      email,
      password: hashed,
      role: role || "user", // default role is "user"
    });

    res.status(201).json({
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        email: user.email,
        role: user.role,
      },
      token: generateToken(user), // <— pass full user so role is included
    });

  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
});

// ===== LOGIN =====
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: "Invalid credentials" });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ message: "Invalid credentials" });

    res.json({
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        email: user.email,
        role: user.role,
      },
      token: generateToken(user), // <— pass full user so role is included
    });

  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error" });
  }
});

// ===== CURRENT USER =====
router.get("/me", protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (error) {
    console.error("Get Me Error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
