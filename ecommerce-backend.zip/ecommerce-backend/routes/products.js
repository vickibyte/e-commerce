const express = require("express");
const { protect, adminOnly } = require("../middleware/authMiddleware");
const Product = require("../models/Product");

const router = express.Router();

// ✅ Admin dashboard
router.get("/dashboard", protect, adminOnly, async (req, res) => {
  try {
    res.json({ message: `Welcome Admin ${req.user?.name || 'Unknown'}` });
  } catch (error) {
    console.error("Dashboard Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ✅ Get all products
router.get("/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ✅ Create a product (Admin only)
router.post("/products", protect, adminOnly, async (req, res) => {
  try {
    const { name, price, stock, category, images } = req.body;
    const product = new Product({ name, price, stock, category, images });
    const savedProduct = await product.save();
    res.status(201).json(savedProduct);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// ✅ Update a product (Admin only)
router.put("/products/:id", protect, adminOnly, async (req, res) => {
  try {
    const { id } = req.params;
    const updatedProduct = await Product.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!updatedProduct) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json(updatedProduct);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// ✅ Delete a product (Admin only)
router.delete("/products/:id", protect, adminOnly, async (req, res) => {
  try {
    const { id } = req.params;
    const deletedProduct = await Product.findByIdAndDelete(id);

    if (!deletedProduct) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json({ message: "Product deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
