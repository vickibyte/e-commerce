const express = require("express");
const User = require("../models/User");
const router = express.Router();
const auth = require("../middleware/authMiddleware");

// /api/users/check-username? username=foo

router.get("/check-username", async(req, res) => {
    try {
        const { username } = req.query;
        if (!username) return
        res.status(400).json({ message: "Username is required" });

        const exists = await
        User.findOne({ username });
        res.json({ exists: !!exists })
    }   catch (e) {
        console.error(e);
        res.status(500).json({ message: "Server error" });
    }
});

// Profile route: only logged-in users can see it
router.get("/profile", auth(), (req, res) => {
  res.json({ message: `Welcome ${req.user.name}`, user: req.user });
});

module.exports = router;