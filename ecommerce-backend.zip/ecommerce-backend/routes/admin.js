const express = require("express");
const { protect, adminOnly } = require("../middleware/authMiddleware");
const {
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  getProductById,
} = require("../controllers/productController");

const router = express.Router();

// Verify middleware exports
console.log("Auth Middlewares:", typeof protect, typeof adminOnly);
console.log("Product Controllers:", {
  getProducts: typeof getProducts,
  createProduct: typeof createProduct,
  updateProduct: typeof updateProduct,
  deleteProduct: typeof deleteProduct,
  getProductById: typeof getProductById,
});

// ✅ Admin Dashboard
router.get("/dashboard", protect, adminOnly, async (req, res) => {
  try {
    res.json({ message: `Welcome Admin ${req.user?.name || "Unknown"}` });
  } catch (error) {
    console.error("Dashboard Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ✅ Products CRUD routes
router.get("/products", protect, adminOnly, getProducts);        // Get all products
router.get("/products/:id", protect, adminOnly, getProductById); // Get single product
router.post("/products", protect, adminOnly, createProduct);     // Create product
router.put("/products/:id", protect, adminOnly, updateProduct);  // Update product
router.delete("/products/:id", protect, adminOnly, deleteProduct); // Delete product

module.exports = router;
