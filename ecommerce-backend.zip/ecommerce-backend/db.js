const { MongoClient } = require("mongodb");
const uri = process.env.MONGO_URI;
let db;

async function connectDB() {
  const client = new MongoClient(uri);
  await client.connect();
  db = client.db();
  console.log("MongoDB connected!");
  return db;
}

function getDB() {
  if (!db) throw new Error("Database not connected");
  return db;
}

module.exports = { connectDB, getDB };
